<h1 style="position:static;top;300px;text-align:center;width:100%;padding:40px;background-color:red;color:white;margin-top:100px">
    <div class="alert alert-danger" role="alert">
        <strong>Erreur:</strong> <?= htmlspecialchars($error) ?>
    </div>    
</h1>
<?php
namespace models;
use models\DatabaseConnexion;

/**
 * Classe représentant un enseignant
 */
class Teachers extends User {
    public string $dateEmbauche;//<la date d'embauche de l'enseignant
    public ?int $idDepartement;

    public function __construct(
        int $id,
        string $nom,
        string $prenom,
        string $dateNaissance,
        string $email,
        string $dateEmbauche,
        string $createdBy = 'system',
        ?int $idDepartement = null,
        ?string $modifiedBy = ''
    ) {
        parent::__construct($id, $nom, $prenom, $email, $dateNaissance, $createdBy, $modifiedBy);
        $this->dateEmbauche = $dateEmbauche;
        $this->idDepartement = $idDepartement;
    }

    /**
     * Sélectionne un étudiant par son Courriel
     * @param string $email l'email de l'étudiant
     */
    public static function selectByEmail($email) {
        $stmt = DatabaseConnexion::getInstance()->prepare('
            SELECT id, nom, prenom, email, dateNaissance, createdBy, modifiedBy, da, dateEmbauche
            FROM Enseignant
            WHERE email = :email'
        );
        $stmt->execute(['email' => $email]);
        if ($stmt->rowCount() > 0) {
            return new Teacher(
                $stmt->fetch(\PDO::FETCH_ASSOC)['id'],
                $stmt->fetch(\PDO::FETCH_ASSOC)['nom'],
                $stmt->fetch(\PDO::FETCH_ASSOC)['prenom'],
                $stmt->fetch(\PDO::FETCH_ASSOC)['email'],
                $stmt->fetch(\PDO::FETCH_ASSOC)['dateNaissance'],
                $stmt->fetch(\PDO::FETCH_ASSOC)['createdBy'],
                $stmt->fetch(\PDO::FETCH_ASSOC)['modifiedBy'],
                $stmt->fetch(\PDO::FETCH_ASSOC)['da'],
                $stmt->fetch(\PDO::FETCH_ASSOC)['dateInscription']
            );
        }
        return false;
    }

    /**
     * Vérifie les informations de connexion de l'enseignant
     * @param string $password Le mot de passe de l'enseignant
     * @return bool true si les informations de connexion sont valides, sinon false
     */
    public function connexion($password) {
        $stmt = DatabaseConnexion::getInstance()->prepare('SELECT password FROM Enseignant WHERE email = :email');
        $stmt->bindValue(':email', $this->email);
        $stmt->execute();
        if ($stmt->rowCount() > 0) {
            $hashedPassword = $stmt->fetch(\PDO::FETCH_ASSOC)['password'];
            return password_verify($password, $hashedPassword);
        }
        return false;
    }

public static function getAll($page = null, $searchValue = '')
{
    $params = [];
    $sql = 'SELECT id, nom, prenom, dateNaissance, email, dateEmbauche, createdBy, modifiedBy, idDepartement
            FROM Enseignant';

    // Add WHERE clause if search value is provided
    if (!empty($searchValue)) {
        $sql .= ' WHERE nom LIKE :search OR prenom LIKE :search OR email LIKE :search';
        $params['search'] = '%' . $searchValue . '%';
    }

    // Only apply LIMIT/OFFSET if page is given
    if (!is_null($page)) {
        $limit = 10;
        $offset = ($page - 1) * $limit;
        $sql .= ' LIMIT :limit OFFSET :offset';
    }

    $stmt = DatabaseConnexion::getInstance()->prepare($sql);

    // Bind search param
    if (!empty($searchValue)) {
        $stmt->bindValue(':search', $params['search'], \PDO::PARAM_STR);
    }

    // Bind pagination params if page is set
    if (!is_null($page)) {
        $stmt->bindValue(':limit', (int)$limit, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', (int)$offset, \PDO::PARAM_INT);
    }

    $stmt->execute();

    $teachers = [];
    while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
        $teachers[] = new Teachers(
            $row['id'],
            $row['nom'],
            $row['prenom'],
            $row['dateNaissance'],
            $row['email'],
            $row['dateEmbauche'],
            $row['createdBy'],
            isset($row['idDepartement']) ? (int)$row['idDepartement'] : null,
            $row['modifiedBy'] ?? ''
        );
    }
    return $teachers;
}


}
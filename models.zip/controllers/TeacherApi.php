<?php
namespace controllers;
use models\Teachers;

class TeacherApi {

    public function __construct() {
        
        header('Content-Type: application/json');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
        header('Access-Control-Allow-Headers: Content-Type');
    }

    /**
     * Récupère tous les Enseignants
     * @return string JSON contenant la liste des enseignants
     */
    public function getTeachers($page = 1) {
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $query = isset($_GET['query']) ? $_GET['query'] : '';
        if($query){
            $teachers = Teachers::getAll($page, $query);
        }else{
            $teachers = Teachers::getAll($page);
        }
        return json_encode($teachers);
    }



}
<?php
use PHPUnit\Framework\TestCase;

//executer avec:     docker exec -it tp2_n46-php-1 ./vendor/bin/phpunit tests/connexionTest.php (depend du nom du docker)
//Je les run sur docker parce que sa prend une connexion a la bd absolument pour tester mon modele
//Puisque toutes les méthodes performent des lectures/écritures
class connexionTest extends TestCase
{
    protected $pdo;

    protected function setUp(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if (!defined('ROOT_PATH')) {
            define('ROOT_PATH', dirname(__DIR__) . '/');
        }
        if (!defined('APP_PATH')) {
            define('APP_PATH', ROOT_PATH . 'app/');
        }
        if (!defined('CONFIG_PATH')) {
            define('CONFIG_PATH', ROOT_PATH . 'config/');
        }
        if (!defined('CONTROLLERS_PATH')) {
            define('CONTROLLERS_PATH', ROOT_PATH . 'controllers/');
        }
        if (!defined('MODELS_PATH')) {
            define('MODELS_PATH', ROOT_PATH . 'models/');
        }
        if (!defined('VIEWS_PATH')) {
            define('VIEWS_PATH', ROOT_PATH . 'views/');
        }
        if (!defined('ROUTES_PATH')) {
            define('ROUTES_PATH', ROOT_PATH . 'routes/');
        }

        $this->pdo = \models\DatabaseConnexion::getInstance();
    }
    public function testDatabaseConnection()
    {
        $this->assertNotNull($this->pdo); // Ensure the PDO object is not null
        $this->assertInstanceOf(PDO::class, $this->pdo); // Ensure it's an instance of PDO
    }
    public function testAuthControllerInstance(){
        $controller =  new \controllers\AuthentificationController;
        $this->assertNotNull($controller);
    }
    public function testConnexion()
    {
        $_POST['role'] = 'Admin';
        $_POST['email'] = 'root@root.com';
        $_POST['password'] = 'root';
        $controller = $this->getMockBuilder(\controllers\AuthentificationController::class)
            ->onlyMethods(['doExit', 'doRedirect'])
            ->getMock();
        $controller->method('doExit')->willReturn(null);
        $controller->method('doRedirect')->willReturn(null);
        $controller->login();
        $this->assertNotNull($_SESSION['user_email']);
        //Test déconnexion
        $controller->disconnect();
        $this->assertEmpty($_SESSION);
        $_POST['role'] = 'Admin';
        $_POST['email'] = 'root@root.com';
        $_POST['password'] = 'WrongPassword';
        $controller->login();
        $this->assertEmpty($_SESSION['user_email']);
    }


}

<?php
require VIEWS_PATH . 'Navbar/StudentNavbar.php';